class GroupMembershipsController < ApplicationController
  def create
    @room = Room.find_by(name: params[:room_name])
    @group_membership = @room.group_memberships.build(group_membership_params)
    if @group_membership.save
     format.html { redirect_to group_membership_url(@group_membership), notice: "Friend was successfully created." }
      format.json { render :show, status: :created, location: @fgroup_membership}
    else
      format.html { render :new, status: :unprocessable_entity }
      format.json { render json: @group_membership.errors, status: :unprocessable_entity }
    end
  end

  # ...
end