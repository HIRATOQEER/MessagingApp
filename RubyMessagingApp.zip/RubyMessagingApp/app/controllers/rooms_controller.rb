class RoomsController < ApplicationController

  def index 
    @current_user = current_user
    redirect_to '/signin' unless @current_user
    @rooms = Room.all
    @users = User.all_except(@current_user)
    @room = Room.new
  end
  def create
    @room = Room.new(name: params["room"]["name"])
     @room.save
    Participant.create(user: current_user, room: @room)
    redirect_to @room, notice: 'Chatroom created successfully.'
  
  end
  def join
  @rooms = Room.find(params[:id])
  @user = User.find(params[:user_id])
  @participants = Participants.new(user: @user, rooms: @rooms)

  if @participants.save
    redirect_to @room, notice: 'User joined successfully.'
  else
    redirect_to @room, alert: 'Failed to join user.'
  end
  end
  def show
  @current_user = current_user
  @single_room = Room.find(params[:id])
  @rooms = Room.public_rooms
  @users = User.all
  @users = User.all_except(@current_user)
  @room = Room.new
   @message = Message.new
   @messages = @single_room.messages
     @room = Room.find(params[:id])

  render "index"
end
end