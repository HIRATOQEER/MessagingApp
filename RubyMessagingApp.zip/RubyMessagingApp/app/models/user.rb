class User < ApplicationRecord
  has_many :group_memberships
  has_many :groups, through: :group_memberships
  has_many :messages
  
  validates_uniqueness_of :username
  scope :all_except, ->(user) { where.not(id: user) }
  after_create_commit { broadcast_append_to "users" }
end
