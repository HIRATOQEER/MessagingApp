class CreateGroupMemberships < ActiveRecord::Migration[7.0]
 belongs_to :user, class_name: 'User'
  belongs_to :room, class_name: 'Room'
    def change
    create_table :group_memberships do |t|
      t.integer :group_id
      t.integer :user_id

      t.timestamps
    end
  end
end
