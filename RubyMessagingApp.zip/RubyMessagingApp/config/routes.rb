Rails.application.routes.draw do
  
  resources :rooms
  resources :users
resources :room_group_memberships
   resources :rooms, param: :name do
  resources :messages
  resources :participants
  post 'group_memberships', to: 'group_memberships#create', as: :room_group_memberships
end

    root 'rooms#index'
   get '/signin', to: 'sessions#new'
  post '/signin', to: 'sessions#create'
  delete '/signout', to: 'sessions#destroy'
end
